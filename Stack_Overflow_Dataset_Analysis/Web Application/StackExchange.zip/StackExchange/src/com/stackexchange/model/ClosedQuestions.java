package com.stackexchange.model;

public class ClosedQuestions 
{
	private String tagName;
	private int tagCount;
	public String getTagName() {
		return tagName;
	}
	public void setTagName(String tagName) {
		this.tagName = tagName;
	}
	public int getTagCount() {
		return tagCount;
	}
	public void setTagCount(int tagCount) {
		this.tagCount = tagCount;
	}
	
	
	
	
}
