package com.stackexchange.connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class HiveConnector 
{
	public Connection getHiveConnection() throws SQLException
	{
		final String driverName = "org.apache.hadoop.hive.jdbc.HiveDriver";
		
		try {
		      Class.forName(driverName);
		    } catch (ClassNotFoundException e) {
		      // TODO Auto-generated catch block
		      e.printStackTrace();
		      System.exit(1);
		    }
		    
		 Connection con = DriverManager.getConnection("jdbc:hive://192.168.1.102:10000/default","","");;
		     
		  return con;
		
	}
}
