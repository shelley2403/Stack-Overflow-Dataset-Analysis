package com.stackexchange.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.stackexchange.connection.HiveConnector;
import com.stackexchange.model.DeadAccount;
import com.stackexchange.model.PageRank;

public class PageRankDao 
{
	public ArrayList<PageRank> getPageRank() throws SQLException
	{
		HiveConnector connector = new HiveConnector();
		Connection conn = connector.getHiveConnection();
		Statement stmt = conn.createStatement();
		
		ArrayList<PageRank>pageRanks = new ArrayList<PageRank>();
		
	//	stmt.executeQuery("create table PageRankHive(postId int,rank string) ROW FORMAT DELIMITED FIELDS TERMINATED BY ',' STORED AS TEXTFILE");
	  // stmt. executeQuery("LOAD DATA INPATH '/pigresults/pageRank/part-r-00000' INTO TABLE PageRankHive");
		    
		    ResultSet res3 = stmt. executeQuery("SELECT * from PageRankHive ORDER BY rank DESC LIMIT 50");
		    
		    while(res3.next())
		    {
		    	
		    PageRank da = new PageRank();
		    da.setPostId(res3.getString(1));
		     da.setRank(Float.parseFloat(res3.getString(2)));
		     
		     pageRanks.add(da);
		    }
		    
		    return pageRanks;  
		 
	}
}
