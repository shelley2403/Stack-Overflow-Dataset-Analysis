package com.stackexchange.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.stackexchange.connection.HiveConnector;
import com.stackexchange.model.TopQuestions;
import com.stackexchange.model.ClosedQuestions;
import com.stackexchange.model.CommentToAnswer;
import com.stackexchange.model.DeadAccount;
import com.stackexchange.model.TagCount;
import com.stackexchange.model.UnAnsweredQs;


public class ChartsDao 
{
	public ArrayList<DeadAccount> getMonthlyResult() throws SQLException
	{
		HiveConnector connector = new HiveConnector();
		Connection conn = connector.getHiveConnection();
		Statement stmt = conn.createStatement();
		
		ArrayList<DeadAccount>deadAccounts = new ArrayList<DeadAccount>();
		
		//stmt.executeQuery("create table MonthlyDeletePosts(datestime string,count int) ROW FORMAT DELIMITED FIELDS TERMINATED BY ',' STORED AS TEXTFILE");
	   //stmt. executeQuery("LOAD DATA INPATH '/pigresults/deletionPostsMonthlyResult/part-r-00000' INTO TABLE MonthlyDeletePosts");
		    
		    ResultSet res3 = stmt. executeQuery("SELECT * from MonthlyDeletePosts");
		    
		    while(res3.next())
		    {
		    	
		    DeadAccount da = new DeadAccount();
		    da.setDate(res3.getString(1));
		    da.setCount(Integer.parseInt(res3.getString(2)));
		     deadAccounts.add(da);
		    }
		    
		    return deadAccounts;  
		 
	}
	
	
	
	public ArrayList<UnAnsweredQs>getSpamPosts() throws SQLException
	{
		HiveConnector connector = new HiveConnector();
		Connection conn = connector.getHiveConnection();
		Statement stmt = conn.createStatement();
		
		
		//stmt.executeQuery("create table SpamPosts(anme string,comment int,spam int) ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t' STORED AS TEXTFILE");
		//stmt. executeQuery("LOAD DATA INPATH '/mypigresults/spam/part-r-00000' INTO TABLE SpamPosts");
			    
		ArrayList<UnAnsweredQs>ac = new ArrayList<UnAnsweredQs>();
			
			ResultSet res3 = stmt. executeQuery("SELECT * from SpamPosts");
		
			
			    while(res3.next())
			    {
			    	
			    		UnAnsweredQs ac2 = new UnAnsweredQs();
			    		ac2.setType("Spams");
			    		ac2.setCount(Integer.parseInt(res3.getString(3)));
			    		
			    		
			    		ac.add(ac2);
			    	}
			    	
			    	
				   
				  
				return ac;
				}
	
	public ArrayList<UnAnsweredQs>getUnAnsweredQs() throws SQLException
	{
		HiveConnector connector = new HiveConnector();
		Connection conn = connector.getHiveConnection();
		Statement stmt = conn.createStatement();
		
		
	//	stmt.executeQuery("create table QsUnanswered(postid int,score int) ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t' STORED AS TEXTFILE");
	//	stmt. executeQuery("LOAD DATA INPATH '/pigresults/pigunanswered1/part-r-00000' INTO TABLE QsUnanswered");
			    
		ArrayList<UnAnsweredQs>ac = new ArrayList<UnAnsweredQs>();
			
			ResultSet res3 = stmt. executeQuery("SELECT * from QsUnanswered");
		
			
			    while(res3.next())
			    {
			    	
			    	UnAnsweredQs ac1 = new UnAnsweredQs();
			    		ac1.setType("Answered");
			    		ac1.setCount(Integer.parseInt(res3.getString(1)));
			    		
			    		UnAnsweredQs ac2 = new UnAnsweredQs();
			    		ac2.setType("UnAnswered");
			    		ac2.setCount(Integer.parseInt(res3.getString(2)));
			    		
			    		ac.add(ac1);
			    		ac.add(ac2);
			    	}
			    	
			    	
				   
				  
				return ac;
				}
				
		
	
	
	public ArrayList<TopQuestions>getTopQuestions() throws SQLException
	{
		HiveConnector connector = new HiveConnector();
		Connection conn = connector.getHiveConnection();
		Statement stmt = conn.createStatement();
		
		
	//	stmt.executeQuery("create table Top100Q(postid int,score int) ROW FORMAT DELIMITED FIELDS TERMINATED BY ',' STORED AS TEXTFILE");
		//stmt. executeQuery("LOAD DATA INPATH '/pigresults/top100Q/part-r-00000' INTO TABLE Top100Q");
			    
		ArrayList<TopQuestions>ac = new ArrayList<TopQuestions>();
			
			ResultSet res3 = stmt. executeQuery("SELECT * from Top100Q LIMIT 20");
			    
			System.out.println(res3);
			
			    while(res3.next())
			    {
			    	TopQuestions ac1 = new TopQuestions();
			    	ac1.setPostId(res3.getString(1));
			    	ac1.setScore(Float.parseFloat(res3.getString(2)));
			    	
			    	ac.add(ac1);
				}
				
			   
			  
		return ac;
	}
	
	public ArrayList<CommentToAnswer>getDetails() throws SQLException
	{
		HiveConnector connector = new HiveConnector();
		Connection conn = connector.getHiveConnection();
		Statement stmt = conn.createStatement();
		
		
		//stmt.executeQuery("create table CommentToAnswer(commentid int,score int) ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t' STORED AS TEXTFILE");
		//stmt. executeQuery("LOAD DATA INPATH '/user/hdadmin/pigresults/CommentToAnswer/part-r-00000' INTO TABLE CommentToAnswer");
			    
		ArrayList<CommentToAnswer>cta = new ArrayList<CommentToAnswer>();
			
			ResultSet res3 = stmt. executeQuery("SELECT * from CommentToAnswer LIMIT 120");
			    
			System.out.println(res3);
			
			    while(res3.next())
			    {
			    	System.out.println(res3.getString(1));
			    	System.out.println(res3.getString(2));
			    	CommentToAnswer comment = new CommentToAnswer();
			    	comment.setCommentId(res3.getString(1));
			    	comment.setScore(Float.parseFloat(res3.getString(2)));
			    	
			    	cta.add(comment);
				}
				
			   
			  
		return cta;
	}
	
	
	
	public ArrayList<TagCount>getRecommendedTags(ArrayList<TagCount>mahoutTagIds) throws SQLException
	{
		HiveConnector connector = new HiveConnector();
		Connection conn = connector.getHiveConnection();
		Statement stmt = conn.createStatement();
		
	//	stmt.executeQuery("create table mahoutTags(tagid int,tagname string) ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t' STORED AS TEXTFILE");
	//	stmt. executeQuery("LOAD DATA INPATH '/stackexchange/Tags.txt' INTO TABLE mahoutTags");
				
		ArrayList<TagCount>finalTitles = new ArrayList<TagCount>();
			
		for(TagCount tc : mahoutTagIds)    
			{
			
			System.out.println("In For Loop"+tc.getTagId());
			ResultSet res3 = stmt. executeQuery("select tagname from mahoutTags where tagid ="+tc.getTagId());
			    
			    while(res3.next())
			    {
			    	System.out.println("In While Loop"+res3.getString(1));
			    	 TagCount tc1 = new TagCount();
				     tc1.setTagName(res3.getString(1));
				     finalTitles.add(tc1);
				     
				    }
				
			}   
			  
		return finalTitles;
	}
	
	public ArrayList<DeadAccount> getDeadPosts() throws SQLException
	{
		HiveConnector connector = new HiveConnector();
		Connection conn = connector.getHiveConnection();
		Statement stmt = conn.createStatement();
		
		ArrayList<DeadAccount>deadAccounts = new ArrayList<DeadAccount>();
		
	//	stmt.executeQuery("create table PostsDelete(datestime string,count int) ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t' STORED AS TEXTFILE");
	//    stmt. executeQuery("LOAD DATA INPATH '/pigresults/deletionPostsMonthly/part-r-00000' INTO TABLE PostsDelete");
		    
		    ResultSet res3 = stmt. executeQuery("SELECT * from PostsDelete");
		    
		    while(res3.next())
		    {
		    	System.out.println(res3.getString(1));
		    DeadAccount da = new DeadAccount();
		    da.setDate(res3.getString(1));
		    da.setCount(Integer.parseInt(res3.getString(2)));
		     deadAccounts.add(da);
		    }
		    
		    return deadAccounts;  
		 
	}
	
	
	
	
	public ArrayList<DeadAccount> getDeadAccounts() throws SQLException
	{
		HiveConnector connector = new HiveConnector();
		Connection conn = connector.getHiveConnection();
		Statement stmt = conn.createStatement();
		
		ArrayList<DeadAccount>deadAccounts = new ArrayList<DeadAccount>();
		
	//	stmt.executeQuery("create table DeadAccont(datestime string,count int) ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t' STORED AS TEXTFILE");
	//    stmt. executeQuery("LOAD DATA INPATH '/pigresults/deadAccount/part-r-00000' INTO TABLE DeadAccont");
		    
		    ResultSet res3 = stmt. executeQuery("SELECT * from DeadAccont ORDER BY datestime DESC LIMIT 10");
		    
		    while(res3.next())
		    {
		    	System.out.println(res3.getString(1));
		    DeadAccount da = new DeadAccount();
		    da.setDate(res3.getString(1));
		    da.setCount(Integer.parseInt(res3.getString(2)));
		     deadAccounts.add(da);
		    }
		    
		    return deadAccounts;  
		 
	}
	
	
	
	public ArrayList<ClosedQuestions> getClosedQuestions() throws SQLException
	{
		HiveConnector connector = new HiveConnector();
		Connection conn = connector.getHiveConnection();
		Statement stmt = conn.createStatement();
		
		ArrayList<ClosedQuestions> closedcount = new ArrayList<>();
		
		
		//stmt.executeQuery("create table closedQuestionHive(tagname string,postid int,date string,time string) ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t' STORED AS TEXTFILE");
		 //  stmt. executeQuery("LOAD DATA INPATH '/pigresults/closedQuestions/part-r-00000' INTO TABLE closedQuestionHive");
		    
		    ResultSet res3 = stmt. executeQuery("SELECT tagname, count(postid) AS count FROM closedQuestionHive GROUP BY tagname ORDER BY count DESC limit 10");
		  
		    System.out.println(res3);
		    
		    
		    while(res3.next())
		    {
		     ClosedQuestions tc = new ClosedQuestions();
		     System.out.println(res3.getString(1));
		     tc.setTagName(res3.getString(1));
		     tc.setTagCount(Integer.parseInt(res3.getString(2)));
		     
		     closedcount.add(tc);
		     
		    }
		    
		    return closedcount;  
		
	}
	
	
	public ArrayList<TagCount> getTagCount() throws SQLException
	{
		HiveConnector connector = new HiveConnector();
		Connection conn = connector.getHiveConnection();
		Statement stmt = conn.createStatement();
		
		ArrayList<TagCount> tagcount = new ArrayList<TagCount>();
		
		 
		
	//	 stmt.executeQuery("create table tagcountHive(tagcount int,tagname string) ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t' STORED AS TEXTFILE");
	  //   stmt. executeQuery("LOAD DATA INPATH '/pigresults/TagCount/part-r-00000' INTO TABLE tagcountHive");
		    ResultSet res2 = stmt. executeQuery("select * from tagcountHive limit 30");
		System.out.println(res2);    
		   
		    while(res2.next())
		    {
		    	System.out.println(res2.getString(1));
		     TagCount tc = new TagCount();
		     tc.setTagCount(Integer.parseInt(res2.getString(1)));
		     tc.setTagName(res2.getString(2));
		     tagcount.add(tc);
		     
		    }
		return tagcount;
		
		
		}
}
