package com.stackexchange.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.stackexchange.connection.HiveConnector;
import com.stackexchange.model.TopQuestions;

public class TrendingQuestionsDao 
{
	public ArrayList<TopQuestions>getTopQuestions() throws SQLException
	{
		HiveConnector connector = new HiveConnector();
		Connection conn = connector.getHiveConnection();
		Statement stmt = conn.createStatement();
		
		
		//stmt.executeQuery("create table TrendingQs(id int,owner int,title string) ROW FORMAT DELIMITED FIELDS TERMINATED BY ',' STORED AS TEXTFILE");
		//stmt. executeQuery("LOAD DATA INPATH '/pigresults/top100Q/part-r-00000' INTO TABLE TrendingQs");
			    
		ArrayList<TopQuestions>ac = new ArrayList<TopQuestions>();
			
			ResultSet res3 = stmt. executeQuery("SELECT title from TrendingQs");
			    
			System.out.println(res3);
			
			    while(res3.next())
			    {
			    	TopQuestions ac1 = new TopQuestions();
			    	ac1.setTitle(res3.getString(1));
			    	ac.add(ac1);
				}
				
			   
			  
		return ac;
	}
}
