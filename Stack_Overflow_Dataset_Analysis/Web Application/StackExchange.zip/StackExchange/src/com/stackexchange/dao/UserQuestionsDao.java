package com.stackexchange.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.stackexchange.connection.HiveConnector;
import com.stackexchange.model.ClosedQuestions;
import com.stackexchange.model.UserAnswers;
import com.stackexchange.model.UserQuestions;

public class UserQuestionsDao 
{
	public ArrayList<UserQuestions> getUserQuestions(String owner) throws SQLException
	{
		HiveConnector connector = new HiveConnector();
		Connection conn = connector.getHiveConnection();
		Statement stmt = conn.createStatement();
		
		ArrayList<UserQuestions> qs = new ArrayList<>();
		
		 ResultSet res3 = stmt. executeQuery("SELECT Title,ViewCount from PostQuestionsHive where OwnerUserId = "+owner+" limit 20");
		 
		    while(res3.next())
		    {
		     UserQuestions uq = new UserQuestions();
		    uq.setTitle(res3.getString(1));
		    uq.setViewCount(Integer.parseInt(res3.getString(2)));
		     
		     qs.add(uq);
		     
		    }
		    
		    return qs;  
	}
	
	public ArrayList<UserAnswers> getUserAnswers(String owner) throws SQLException
	{
		HiveConnector connector = new HiveConnector();
		Connection conn = connector.getHiveConnection();
		Statement stmt = conn.createStatement();
		
		
		ArrayList<UserAnswers> qa = new ArrayList<>();
		
		 ResultSet res4 = stmt. executeQuery("SELECT Title,Score from PostAnswersHive where OwnerUserId = "+owner+" limit 20"); 
		 
		    while(res4.next())
		    {
		     UserAnswers uq = new UserAnswers();
		    uq.setAnswer(res4.getString(1));
		    uq.setScore(Float.parseFloat(res4.getString(2)));
		     
		     qa.add(uq);
		     
		    }
		    
		    return qa;  
	}
}
