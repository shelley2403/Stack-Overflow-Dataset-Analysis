package com.stackexchange.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.stackexchange.connection.HiveConnector;
import com.stackexchange.model.Posts;

public class PostsDao 
{
	public ArrayList<Posts> getMaxScore() throws SQLException
	{
		HiveConnector connector = new HiveConnector();
		Connection conn = connector.getHiveConnection();
		Statement stmt = conn.createStatement();
		
		ArrayList<Posts>posts = new ArrayList<Posts>();
		
		    
		    ResultSet res3 = stmt. executeQuery("SELECT title,viewcount AS count from PostQuestionsHive ORDER BY count DESC LIMIT 20");
		    
		    while(res3.next())
		    {
		    	
		    Posts p = new Posts();
		    p.setPostId(res3.getString(1));
		    System.out.println(res3.getString(1));
		    p.setScore(res3.getString(2)); 
		     posts.add(p);
		    }
		    
		    return posts;  
		 
	}
	 
	
	public ArrayList<Posts> getMaxView() throws SQLException
	{
		HiveConnector connector = new HiveConnector();
		Connection conn = connector.getHiveConnection();
		Statement stmt = conn.createStatement();
		
		ArrayList<Posts>posts = new ArrayList<Posts>();
		
		    
		    ResultSet res3 = stmt. executeQuery("SELECT count(view) AS count from postQuestionsHive ORDER BY count DESC");
		    
		    while(res3.next())
		    {
		    	
		    Posts p = new Posts();
		    p.setScore(res3.getString(1));
		     
		     posts.add(p);
		    }
		    
		    return posts;  
		 
	}
}
