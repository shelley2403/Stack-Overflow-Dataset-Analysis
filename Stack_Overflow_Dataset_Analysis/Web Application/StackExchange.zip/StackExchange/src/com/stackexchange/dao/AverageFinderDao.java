package com.stackexchange.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.stackexchange.connection.HiveConnector;
import com.stackexchange.model.UnAnsweredQs;

public class AverageFinderDao 
{

	public String getAverage(String tag1, String tag2) throws SQLException
	{
		HiveConnector connector = new HiveConnector();
		Connection conn = connector.getHiveConnection();
		Statement stmt = conn.createStatement();
		
		
		//stmt.executeQuery("create table AverageFinder(tagname string,time string) ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t' STORED AS TEXTFILE");
		//stmt. executeQuery("LOAD DATA INPATH '/pigresults/promptness/part-r-00000' INTO TABLE AverageFinder");
			    
		
			
			ResultSet res3 = stmt. executeQuery("SELECT time from AverageFinder where tagname = '"+tag1+"' OR tagname = '"+tag2+"'");
		
			long tag11 = 0;
			long tag12 = 0;
			int i = 0;
			
			    while(res3.next())
			    {
			    	System.out.println(res3.getString(1));
			    	i++;
			    	if(i==1)
			    		tag11 = Long.parseLong(res3.getString(1));
			    	else
			    		tag12 = Long.parseLong(res3.getString(1));
			    		
			    }
			    if(tag12!=0 && tag11!=0)
			    {
			    	long milliSeconds = (tag11 + tag12)/2;
			    	
			    	long diffSeconds = milliSeconds / 1000 % 60;

			        long diffMinutes = milliSeconds / (60 * 1000) % 60;

			        long diffHours = milliSeconds / (60 * 60 * 1000) % 24;

			        long diffDays = milliSeconds / (24 * 60 * 60 * 1000);
				   
				  
			        String returns1 = diffDays+" days "+diffHours+" hours "+diffMinutes+" Minutes "+diffSeconds+" Seconds";
			        System.out.println(returns1);
				return returns1;
			    }
			    else if(tag11!=0)
			    {
long milliSeconds = tag11;
			    	
			    	long diffSeconds = milliSeconds / 1000 % 60;

			        long diffMinutes = milliSeconds / (60 * 1000) % 60;

			        long diffHours = milliSeconds / (60 * 60 * 1000) % 24;

			        long diffDays = milliSeconds / (24 * 60 * 60 * 1000);
				   
				  
			        String returns1 = diffDays+" days "+diffHours+" hours "+diffMinutes+" Minutes "+diffSeconds+" Seconds";
			        System.out.println(returns1);
				return returns1;
			    }
			    else if(tag12!=0)
			    {
long milliSeconds = tag12;
			    	
			    	long diffSeconds = milliSeconds / 1000 % 60;

			        long diffMinutes = milliSeconds / (60 * 1000) % 60;

			        long diffHours = milliSeconds / (60 * 60 * 1000) % 24;

			        long diffDays = milliSeconds / (24 * 60 * 60 * 1000);
				   
				  
			        String returns1 = diffDays+" days "+diffHours+" hours "+diffMinutes+" Minutes "+diffSeconds+" Seconds";
			        System.out.println(returns1);
				return returns1;
			    }
			    return null;
				}
	
}
